
#' calcul du taux de survie en fonction de la variable données en entrée
#' 
#' @author Bineta 
#' @param data jeuu de données
#' @param variable colonne donnée
#' @examples 
#' taux_survie(data,'passengerClass') 
#' taux_survie(data,'sex')  
#' @export






taux_survie <- function(data,variable) { 
  library(dplyr) 
   data %>% 
    group_by(data[,variable]) %>% 
    summarize(TauxSurvie = sum(survived == "yes") / n())
   }
  
